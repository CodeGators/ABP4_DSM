import React, { useState } from 'react';
import { 
  Text, View, StyleSheet, TouchableOpacity, FlatList, 
  SafeAreaView, TextInput, Modal, KeyboardAvoidingView, Platform, ScrollView
} from 'react-native';

const DIAS_DA_SEMANA = [
  { id: 0, label: 'D' }, { id: 1, label: 'S' }, { id: 2, label: 'T' }, 
  { id: 3, label: 'Q' }, { id: 4, label: 'Q' }, { id: 5, label: 'S' }, { id: 6, label: 'S' }
];

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [abaAtual, setAbaAtual] = useState('home');

  // Estado das gavetas
  const [gavetas, setGavetas] = useState([
    { 
      id: '1', nome: 'Gaveta 1', remedio: 'Amoxicilina', dosagem: '500mg', hora: '12:00', 
      tempoAberto: '5', doseUnica: false, intervalo: '8', tipoUso: 'diario', diasSelecionados: [0,1,2,3,4,5,6], liberado: false 
    },
    { 
      id: '2', nome: 'Gaveta 2', remedio: 'Vitamina C', dosagem: '1 Comprimido', hora: '09:00', 
      tempoAberto: '10', doseUnica: true, intervalo: '', tipoUso: 'especifico', diasSelecionados: [1, 3, 5], liberado: false 
    },
    { 
      id: '3', nome: 'Gaveta 3', remedio: 'Loratadina', dosagem: '10mg', hora: '20:00', 
      tempoAberto: '5', doseUnica: true, intervalo: '', tipoUso: 'diario', diasSelecionados: [0,1,2,3,4,5,6], liberado: false 
    },
  ]);

  // Lista COMPLETA de alertas simulados (Vermelho, Amarelo e Cinza)
  const [avisos] = useState([
    { id: '1', tipo: 'urgente', titulo: 'Gaveta Aberta!', desc: 'A Gaveta 1 excedeu o limite de 5 minutos destrancada.', data: '24/04/2026', hora: '08:05' },
    { id: '2', tipo: 'atraso', titulo: 'Remédio Atrasado', desc: 'Você está 15 minutos atrasado para tomar a Vitamina C.', data: '24/04/2026', hora: '09:15' },
    { id: '3', tipo: 'perdido', titulo: 'Dose Perdida', desc: 'O limite de tempo expirou. A dose de Loratadina não foi retirada e a gaveta foi travada.', data: '23/04/2026', hora: '21:00' },
  ]);

  const [registros, setRegistros] = useState([
    { id: '1', tipo: 'consumo', remedio: 'Amoxicilina', gaveta: 'Gaveta 1', detalhes: 'Dosagem: 500mg', data: '24/04/2026', hora: '12:05', status: 'Consumido' },
    { id: '2', tipo: 'edicao', remedio: 'Vitamina C', gaveta: 'Gaveta 2', detalhes: 'Mudança p/ 1 Comprimido, 09:00', data: '23/04/2026', hora: '15:30', status: 'Alterado' },
    { id: '3', tipo: 'consumo', remedio: 'Vitamina C', gaveta: 'Gaveta 2', detalhes: 'Dosagem: 1 Comprimido', data: '23/04/2026', hora: '09:02', status: 'Consumido' },
  ]);

  // Estados do Modal
  const [modalVisible, setModalVisible] = useState(false);
  const [editingGaveta, setEditingGaveta] = useState(null);
  const [tempRemedio, setTempRemedio] = useState('');
  const [tempDosagem, setTempDosagem] = useState('');
  const [tempHora, setTempHora] = useState('');
  const [tempTempoAberto, setTempTempoAberto] = useState('');
  const [tempDoseUnica, setTempDoseUnica] = useState(true);
  const [tempIntervalo, setTempIntervalo] = useState('');
  const [tempTipoUso, setTempTipoUso] = useState('diario');
  const [tempDias, setTempDias] = useState([]);

  const abrirEditor = (gaveta) => {
    setEditingGaveta(gaveta);
    setTempRemedio(gaveta.remedio);
    setTempDosagem(gaveta.dosagem || '');
    setTempHora(gaveta.hora);
    setTempTempoAberto(gaveta.tempoAberto || '5');
    setTempDoseUnica(gaveta.doseUnica);
    setTempIntervalo(gaveta.intervalo);
    setTempTipoUso(gaveta.tipoUso);
    setTempDias(gaveta.diasSelecionados);
    setModalVisible(true);
  };

  const gerarDataHoraAtual = () => {
    const agora = new Date();
    const dataAtual = `${agora.getDate().toString().padStart(2, '0')}/${(agora.getMonth() + 1).toString().padStart(2, '0')}/${agora.getFullYear()}`;
    const horaAtual = `${agora.getHours().toString().padStart(2, '0')}:${agora.getMinutes().toString().padStart(2, '0')}`;
    return { dataAtual, horaAtual };
  };

  const salvarEdicao = () => {
    setGavetas(gavetas.map(g => 
      g.id === editingGaveta.id ? { 
        ...g, 
        remedio: tempRemedio, dosagem: tempDosagem, hora: tempHora, tempoAberto: tempTempoAberto || '5', 
        doseUnica: tempDoseUnica, intervalo: tempDoseUnica ? '' : tempIntervalo,
        tipoUso: tempTipoUso, diasSelecionados: tempTipoUso === 'diario' ? [0,1,2,3,4,5,6] : tempDias 
      } : g
    ));

    const { dataAtual, horaAtual } = gerarDataHoraAtual();
    const logEdicao = {
      id: Math.random().toString(),
      tipo: 'edicao',
      remedio: tempRemedio,
      gaveta: editingGaveta.nome,
      detalhes: `Ajuste p/ ${tempDosagem || '-'}, 1ª Dose: ${tempHora}, Limite: ${tempTempoAberto || '5'}min`,
      data: dataAtual,
      hora: horaAtual,
      status: 'Modificado'
    };
    
    setRegistros([logEdicao, ...registros]);
    setModalVisible(false);
  };

  const confirmarConsumo = (item) => {
    setGavetas(gavetas.map(g => g.id === item.id ? {...g, liberado: true} : g));
    
    const { dataAtual, horaAtual } = gerarDataHoraAtual();
    const logConsumo = {
      id: Math.random().toString(),
      tipo: 'consumo',
      remedio: item.remedio,
      gaveta: item.nome,
      detalhes: `Dosagem: ${item.dosagem || 'Dose Padrão'}`,
      data: dataAtual,
      hora: horaAtual,
      status: 'Consumido'
    };
    
    setRegistros([logConsumo, ...registros]);
  };

  const calcularProximaDose = (horaInicial, intervalo) => {
    if (!intervalo || intervalo === '0') return "";
    let [h, m] = horaInicial.split(':').map(Number);
    let proximaH = (h + Number(intervalo)) % 24;
    return `Prox: ${proximaH < 10 ? '0' + proximaH : proximaH}:${m < 10 ? '0' + m : m}`;
  };

  // --- TELA DE LOGIN ---
  if (!isLoggedIn) {
    return (
      <View style={styles.loginContainer}>
        <View style={styles.logoCircle}><Text style={styles.loginLogo}>PG</Text></View>
        <Text style={styles.loginTitle}>PillGator</Text>
        <Text style={styles.loginSub}>SISTEMA DE GESTÃO</Text>
        <TextInput style={styles.inputLogin} placeholder="Usuário" placeholderTextColor="#555" />
        <TextInput style={styles.inputLogin} placeholder="Senha" placeholderTextColor="#555" secureTextEntry />
        <TouchableOpacity style={styles.loginButton} onPress={() => setIsLoggedIn(true)}>
          <Text style={styles.loginButtonText}>ACESSAR PAINEL</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // --- RENDERIZADORES DE ABAS ---
  const renderPainel = () => (
    <FlatList
      data={gavetas}
      contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
      renderItem={({ item }) => (
        <View style={[styles.card, item.liberado && styles.cardLiberado]}>
          <View style={styles.cardInfo}>
            <Text style={styles.cardTitle}>{item.nome}: {item.remedio}</Text>
            
            <View style={styles.badgesContainer}>
              <Text style={styles.badgeInfo}>🕒 {item.hora}</Text>
              <Text style={styles.badgeInfo}>💊 {item.dosagem}</Text>
              <Text style={styles.badgeInfo}>⏱️ {item.tempoAberto}min</Text>
              <Text style={[styles.badgeInfo, {color: '#00FF66'}]}>
                {item.doseUnica ? '1x ao dia' : `⏳ A cada ${item.intervalo}h`}
              </Text>
            </View>

            <Text style={styles.recorrenciaText}>
              {item.tipoUso === 'diario' ? `🔄 Uso Diário` : `📅 Dias: ${item.diasSelecionados.map(d => DIAS_DA_SEMANA[d].label).join(', ')}`}
              {!item.doseUnica && ` • ${calcularProximaDose(item.hora, item.intervalo)}`}
            </Text>

            <TouchableOpacity onPress={() => abrirEditor(item)}>
              <Text style={styles.editLink}>Ajustar Configurações</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity 
            style={[styles.liberarBtn, item.liberado && styles.btnOff]} 
            onPress={() => confirmarConsumo(item)}
            disabled={item.liberado}
          >
            <Text style={styles.liberarBtnText}>{item.liberado ? 'OK' : 'Abrir'}</Text>
          </TouchableOpacity>
        </View>
      )}
    />
  );

  const renderRegistros = () => (
    <View style={{ flex: 1, paddingHorizontal: 20 }}>
      <Text style={styles.sectionTitle}>Histórico do Sistema</Text>
      <FlatList
        data={registros}
        renderItem={({ item }) => {
          const isEdicao = item.tipo === 'edicao';
          return (
            <View style={[styles.registroCard, isEdicao && styles.registroCardEdicao]}>
              <View style={styles.registroHeader}>
                <Text style={styles.registroRemedio}>{item.remedio}</Text>
                <View style={[styles.statusPill, isEdicao && styles.statusPillEdicao]}>
                  <Text style={[styles.statusPillText, isEdicao && styles.statusPillTextEdicao]}>
                    {item.status}
                  </Text>
                </View>
              </View>
              <Text style={styles.registroDetalhes}>{item.gaveta} • {item.detalhes}</Text>
              <Text style={styles.registroDataHora}>📅 {item.data} às {item.hora}</Text>
            </View>
          );
        }}
      />
    </View>
  );

  const renderAvisos = () => (
    <View style={{ flex: 1, paddingHorizontal: 20 }}>
      <Text style={styles.sectionTitle}>Central de Alertas</Text>
      <FlatList
        data={avisos}
        renderItem={({ item }) => {
          // Lógica de cores baseada no tipo de aviso
          let borderColor = '#FFB800'; // Amarelo (Atraso)
          if (item.tipo === 'urgente') borderColor = '#FF4444'; // Vermelho (Gaveta Aberta)
          if (item.tipo === 'perdido') borderColor = '#888888'; // Cinza (Dose Perdida)

          return (
            <View style={[styles.avisoCard, { borderLeftColor: borderColor }]}>
              <View style={styles.avisoHeader}>
                <Text style={styles.avisoTitle}>{item.titulo}</Text>
                <Text style={styles.avisoDataHora}>{item.data} • {item.hora}</Text>
              </View>
              <Text style={styles.avisoDesc}>{item.desc}</Text>
            </View>
          );
        }}
      />
    </View>
  );

  // --- ESTRUTURA PRINCIPAL ---
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>PillGator</Text>
        <View style={styles.statusBadge}><View style={styles.statusDot} /><Text style={styles.statusText}>Hardware Conectado</Text></View>
      </View>

      {abaAtual === 'home' && renderPainel()}
      {abaAtual === 'registros' && renderRegistros()}
      {abaAtual === 'avisos' && renderAvisos()}

      {/* MODAL DE CONFIGURAÇÃO */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.modalTitle}>Configurar {editingGaveta?.nome}</Text>
              
              <Text style={styles.label}>Medicamento</Text>
              <TextInput style={styles.input} value={tempRemedio} onChangeText={setTempRemedio} />

              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ width: '48%' }}>
                  <Text style={styles.label}>Dosagem</Text>
                  <TextInput style={styles.input} value={tempDosagem} onChangeText={setTempDosagem} placeholder="Ex: 500mg" />
                </View>
                <View style={{ width: '48%' }}>
                  <Text style={styles.label}>1ª Dose do Dia</Text>
                  <TextInput style={styles.input} value={tempHora} onChangeText={setTempHora} placeholder="Ex: 08:00" />
                </View>
              </View>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 }}>
                <View style={{ width: '100%' }}>
                  <Text style={styles.label}>Tempo Destrancada (Minutos)</Text>
                  <TextInput style={styles.input} value={tempTempoAberto} onChangeText={setTempTempoAberto} keyboardType="numeric" placeholder="Ex: 5" />
                </View>
              </View>

              <Text style={styles.label}>Repetição no Dia</Text>
              <View style={styles.tipoUsoRow}>
                <TouchableOpacity style={[styles.tipoBtn, tempDoseUnica && styles.tipoBtnActive]} onPress={() => setTempDoseUnica(true)}>
                  <Text style={[styles.tipoBtnText, tempDoseUnica && styles.tipoBtnTextActive]}>Dose Única</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.tipoBtn, !tempDoseUnica && styles.tipoBtnActive]} onPress={() => setTempDoseUnica(false)}>
                  <Text style={[styles.tipoBtnText, !tempDoseUnica && styles.tipoBtnTextActive]}>Com Intervalo</Text>
                </TouchableOpacity>
              </View>

              {!tempDoseUnica && (
                <View>
                  <Text style={styles.label}>Intervalo (Horas)</Text>
                  <TextInput style={styles.input} value={tempIntervalo} onChangeText={setTempIntervalo} keyboardType="numeric" placeholder="Ex: 8" />
                </View>
              )}

              <Text style={styles.label}>Dias de Uso</Text>
              <View style={styles.tipoUsoRow}>
                <TouchableOpacity style={[styles.tipoBtn, tempTipoUso === 'diario' && styles.tipoBtnActive]} onPress={() => setTempTipoUso('diario')}>
                  <Text style={[styles.tipoBtnText, tempTipoUso === 'diario' && styles.tipoBtnTextActive]}>Todos os dias</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.tipoBtn, tempTipoUso === 'especifico' && styles.tipoBtnActive]} onPress={() => setTempTipoUso('especifico')}>
                  <Text style={[styles.tipoBtnText, tempTipoUso === 'especifico' && styles.tipoBtnTextActive]}>Dias Específicos</Text>
                </TouchableOpacity>
              </View>

              {tempTipoUso === 'especifico' && (
                <View style={styles.diasRow}>
                  {DIAS_DA_SEMANA.map(dia => (
                    <TouchableOpacity key={dia.id} style={[styles.diaCirculo, tempDias.includes(dia.id) && styles.diaCirculoActive]} onPress={() => {
                      setTempDias(tempDias.includes(dia.id) ? tempDias.filter(id => id !== dia.id) : [...tempDias, dia.id].sort());
                    }}>
                      <Text style={[styles.diaText, tempDias.includes(dia.id) && styles.diaTextActive]}>{dia.label}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
              
              <View style={styles.modalButtons}>
                <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.cancelBtn}><Text style={{color: '#888'}}>Cancelar</Text></TouchableOpacity>
                <TouchableOpacity onPress={salvarEdicao} style={styles.saveBtn}><Text style={{fontWeight: 'bold', color: '#0A0A0A'}}>Salvar</Text></TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem} onPress={() => setAbaAtual('home')}><Text style={{color: abaAtual === 'home' ? '#00FF66' : '#555', fontWeight: 'bold', fontSize: 12}}>Painel</Text></TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setAbaAtual('registros')}><Text style={{color: abaAtual === 'registros' ? '#00FF66' : '#555', fontWeight: 'bold', fontSize: 12}}>Histórico</Text></TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setAbaAtual('avisos')}><Text style={{color: abaAtual === 'avisos' ? '#00FF66' : '#555', fontWeight: 'bold', fontSize: 12}}>Alertas</Text></TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setIsLoggedIn(false)}><Text style={{color: '#444', fontWeight: 'bold', fontSize: 12}}>Sair</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0A0A' },
  loginContainer: { flex: 1, backgroundColor: '#0A0A0A', justifyContent: 'center', padding: 40 },
  logoCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#00FF66', alignSelf: 'center', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  loginLogo: { fontSize: 32, fontWeight: '900', color: '#0A0A0A' },
  loginTitle: { fontSize: 36, fontWeight: 'bold', color: '#fff', textAlign: 'center' },
  loginSub: { color: '#00FF66', textAlign: 'center', marginBottom: 40, letterSpacing: 2, fontSize: 10, fontWeight: 'bold' },
  inputLogin: { backgroundColor: '#161616', color: '#fff', padding: 18, borderRadius: 12, marginBottom: 15, borderWidth: 1, borderColor: '#222' },
  loginButton: { backgroundColor: '#00FF66', padding: 20, borderRadius: 12, marginTop: 10 },
  loginButtonText: { textAlign: 'center', fontWeight: 'bold', color: '#0A0A0A' },
  header: { marginTop: 50, marginBottom: 20, alignItems: 'center' },
  title: { fontSize: 26, fontWeight: 'bold', color: '#00FF66' },
  statusBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#161616', padding: 6, borderRadius: 12, marginTop: 8 },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#00FF66', marginRight: 6 },
  statusText: { color: '#888', fontSize: 10, fontWeight: 'bold' },
  card: { backgroundColor: '#161616', borderRadius: 20, padding: 20, marginBottom: 15, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#222' },
  cardLiberado: { opacity: 0.4 },
  cardInfo: { flex: 1 },
  cardTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  badgesContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 6 },
  badgeInfo: { backgroundColor: '#222', paddingVertical: 4, paddingHorizontal: 8, borderRadius: 6, color: '#aaa', fontSize: 10, fontWeight: 'bold' },
  recorrenciaText: { color: '#888', fontSize: 12, marginTop: 8 },
  editLink: { color: '#444', fontSize: 11, marginTop: 12, textDecorationLine: 'underline' },
  liberarBtn: { backgroundColor: '#00FF66', paddingVertical: 12, paddingHorizontal: 15, borderRadius: 12 },
  liberarBtnText: { fontWeight: 'bold', color: '#0A0A0A' },
  btnOff: { backgroundColor: '#333' },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold', marginBottom: 20 },
  
  // Estilos da aba de Registros
  registroCard: { backgroundColor: '#161616', padding: 16, marginBottom: 12, borderRadius: 15, borderLeftWidth: 4, borderLeftColor: '#00FF66' },
  registroCardEdicao: { borderLeftColor: '#00A3FF' }, // Azul para edições
  registroHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  registroRemedio: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  statusPill: { backgroundColor: 'rgba(0, 255, 102, 0.1)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  statusPillEdicao: { backgroundColor: 'rgba(0, 163, 255, 0.1)' },
  statusPillText: { color: '#00FF66', fontSize: 10, fontWeight: 'bold' },
  statusPillTextEdicao: { color: '#00A3FF' },
  registroDetalhes: { color: '#aaa', fontSize: 13, marginBottom: 4 },
  registroDataHora: { color: '#666', fontSize: 11 },

  // Estilos da aba de Avisos
  avisoCard: { backgroundColor: '#161616', padding: 16, marginBottom: 12, borderRadius: 15, borderLeftWidth: 4 },
  avisoHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 },
  avisoTitle: { color: '#fff', fontWeight: 'bold' },
  avisoDataHora: { color: '#666', fontSize: 10 },
  avisoDesc: { color: '#aaa', fontSize: 13 },

  // Estilos do Modal
  modalOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.95)' },
  modalContent: { backgroundColor: '#161616', borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 25, borderWidth: 1, borderColor: '#333', maxHeight: '90%' },
  modalTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  label: { color: '#00FF66', fontSize: 10, marginBottom: 8, fontWeight: 'bold', textTransform: 'uppercase' },
  input: { backgroundColor: '#0A0A0A', color: '#fff', padding: 15, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: '#222' },
  tipoUsoRow: { flexDirection: 'row', marginBottom: 20, backgroundColor: '#0A0A0A', borderRadius: 12, padding: 4 },
  tipoBtn: { flex: 1, padding: 12, alignItems: 'center', borderRadius: 10 },
  tipoBtnActive: { backgroundColor: '#00FF66' },
  tipoBtnText: { color: '#555', fontWeight: 'bold' },
  tipoBtnTextActive: { color: '#0A0A0A' },
  diasRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  diaCirculo: { width: 35, height: 35, borderRadius: 18, backgroundColor: '#0A0A0A', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#333' },
  diaCirculoActive: { backgroundColor: '#00FF66', borderColor: '#00FF66' },
  diaText: { color: '#666', fontSize: 12, fontWeight: 'bold' },
  diaTextActive: { color: '#0A0A0A' },
  modalButtons: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 10, paddingBottom: 20 },
  saveBtn: { backgroundColor: '#00FF66', paddingVertical: 12, paddingHorizontal: 30, borderRadius: 12, marginLeft: 15 },
  cancelBtn: { justifyContent: 'center' },
  bottomNav: { flexDirection: 'row', height: 80, backgroundColor: '#161616', borderTopWidth: 1, borderTopColor: '#222' },
  navItem: { flex: 1, justifyContent: 'center', alignItems: 'center' }
});